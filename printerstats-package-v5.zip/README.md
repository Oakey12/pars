# PrinterStats

Go-программа определяет сетевые принтеры и собирает метрики по SNMP и из публичного web-интерфейса принтера:

- общий счётчик страниц, а для Command Center RX также копирование, печать и сканирование;
- остаток тонера, чернил или термотрансферной ленты;
- напечатанную длину для поддерживаемых термопринтеров TSC;
- модель, имя устройства, SNMP-версию и способ определения принтера;
- подробную диагностику недоступных и нестандартных устройств.

Локальные права администратора не нужны. В режиме `auto` сначала используется SNMP, а при отсутствии счётчика или тонера программа сама просматривает публичные HTTP/HTTPS-страницы устройства. Вход администратором не выполняется, формы не отправляются, ссылки за пределами IP принтера не открываются.

## Запуск списка из printers.json

Из каталога, где находится go.mod:

~~~powershell
go run ./cmd/printerstats -config .\printers.json
~~~

Сохранение полного результата:

~~~powershell
go run ./cmd/printerstats -config .\printers.json -format json -out .\results.json
go run ./cmd/printerstats -config .\printers.json -format csv -out .\results.csv
~~~

## Проверка одного IP

Файл конфигурации не требуется:

~~~powershell
go run ./cmd/printerstats -ip 192.168.140.30
~~~

Если SNMP выключен, но страница «Счётчик» открывается в браузере, можно не ждать SNMP-таймаут:

~~~powershell
go run ./cmd/printerstats -ip 192.168.50.30 -protocol http -format json
~~~

Программа начинает с `http://IP/`, сохраняет cookies устройства, находит страницы и фреймы со счётчиком/статусом/тонером и разбирает их. Для старого JavaScript-интерфейса Kyocera Command Center RX она также напрямую проверяет `DvcInfo_Counter_PrnCounter.htm`, `DvcInfo_Counter_ScanCounter.htm` и `Hme_Toner.htm`. Если автоматический поиск не нашёл нестандартный адрес страницы, его можно передать явно:

~~~powershell
go run ./cmd/printerstats -ip 192.168.50.30 -protocol http -http-url "http://192.168.50.30/путь-к-счетчику" -format json
~~~

В `printers.json` доступны те же параметры: `"protocol":"auto|snmp|http"` и необязательный `"http_url":"http://IP/..."`. Для `192.168.50.30` уже установлен режим `http`.

По умолчанию программа пробует SNMP v2c, затем v1:

~~~powershell
go run ./cmd/printerstats -ip 192.168.40.32 -version auto -format json
~~~

Если community отличается от public:

~~~powershell
go run ./cmd/printerstats -ip 192.168.140.30 -community read-only-community
~~~

## Диагностический обход vendor-OID

Программа может определить корень enterprise-OID из sysObjectID и приложить до 500 значений к JSON:

~~~powershell
go run ./cmd/printerstats -ip 192.168.140.34 -version 2c -format json -walk-oid auto -out .\kyocera-oids.json
~~~

Явный корень:

~~~powershell
go run ./cmd/printerstats -ip 192.168.40.32 -version 1 -format json -walk-oid .1.3.6.1.4.1.43564 -out .\tsc-oids.json
~~~

Диагностический обход только читает OID и ничего не изменяет на принтере.

## Интерпретация таблицы

- PRINTER=yes — устройство подтверждено как принтер.
- PRINTER=no — SNMP ответил, но признаков принтера нет.
- PRINTER=unknown — SNMP не ответил, поэтому определить устройство невозможно.
- PAGES — счётчик листов/отпечатков.
- LENGTH_KM — напечатанная длина термопринтера.
- SUPPLY% — минимальный остаток основного расходника: тонера, чернил или ленты.
- SOURCE — источник метрик: `snmp`, `http` или оба сразу.
- PRINTED — все напечатанные страницы; PRINT — печать с компьютеров; COPY — копии; SCANNED — все отсканированные страницы.
- SNMP=2c,1 — программа попробовала обе версии.

Для TSC TTP-2410MT/MH240 используется 8 точек/мм, для MH341 — 12 точек/мм. Прошивки TSC могут объявлять ёмкость ленты в микрометрах, но текущий уровень возвращать как целый процент; для этого ограниченного случая применяется vendor-коррекция.

## Сборка EXE

~~~powershell
go build -o printerstats.exe ./cmd/printerstats
.\printerstats.exe -config .\printers.json
~~~

## Ошибки

- request timeout — устройство выключено, SNMP отключён, неверная community, закрыт UDP/161 или нет маршрута.
- HTTP request failed — web-интерфейс недоступен с компьютера, закрыт TCP/80 или TCP/443 либо устройство использует нестандартный URL; его можно указать через `http_url`.
- invalid packet length — старая прошивка/принт-сервер сформировали некорректный пакет. Программа автоматически повторяет запросы метаданных по одному OID.
- partial — принтер определён, но часть стандартных метрик недоступна.

Даже при ошибках отдельных устройств доступные результаты сохраняются. Если хотя бы один включённый адрес завершился с error, процесс возвращает код 1.
