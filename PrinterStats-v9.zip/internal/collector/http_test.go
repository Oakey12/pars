package collector

import (
	"fmt"
	"net"
	"net/http"
	"net/http/httptest"
	"net/url"
	"strings"
	"testing"
	"time"

	"printerstats/internal/config"
)

func TestWebCollectsKyoceraCounterAndTonerPages(t *testing.T) {
	mux := http.NewServeMux()
	mux.HandleFunc("/", func(w http.ResponseWriter, _ *http.Request) {
		fmt.Fprint(w, `<html><head><title>Command Center RX</title></head><body>
		<a href="/counter">Счетчик</a><a href="/status">Состояние задания</a></body></html>`)
	})
	mux.HandleFunc("/counter", func(w http.ResponseWriter, _ *http.Request) {
		fmt.Fprint(w, `<html><body><h2>Напечатанные страницы</h2><table>
		<tr><th>Функция</th><th>Черно-белый</th><th>Общий</th></tr>
		<tr><td>Копирование</td><td>12604</td><td>12604</td></tr>
		<tr><td>Принтер</td><td>190990</td><td>190990</td></tr>
		<tr><td>Общий</td><td>203594</td><td>203594</td></tr></table>
		<h2>Отсканированные страницы</h2><table>
		<tr><th>Функция</th><th>Страницы оригинала</th></tr>
		<tr><td>Копирование</td><td>7110</td></tr>
		<tr><td>Другое</td><td>116358</td></tr>
		<tr><td>Общий</td><td>123468</td></tr></table></body></html>`)
	})
	mux.HandleFunc("/status", func(w http.ResponseWriter, _ *http.Request) {
		fmt.Fprint(w, `<html><body><table><tr><td>Черный тонер</td><td><span title="Осталось 73%">73%</span></td></tr></table></body></html>`)
	})
	server := httptest.NewServer(mux)
	defer server.Close()

	u, err := url.Parse(server.URL)
	if err != nil {
		t.Fatal(err)
	}
	host, _, err := net.SplitHostPort(u.Host)
	if err != nil {
		t.Fatal(err)
	}
	result := (Web{Timeout: time.Second}).Collect(config.Printer{Address: host, HTTPURL: server.URL + "/"})
	if result.Status != "ok" {
		t.Fatalf("status = %q, error = %q, warnings = %v", result.Status, result.Error, result.Warnings)
	}
	if result.TotalPages == nil || *result.TotalPages != 203594 {
		t.Fatalf("total pages = %v", result.TotalPages)
	}
	if result.PageMetrics == nil || result.PageMetrics.PrintedCopy == nil || *result.PageMetrics.PrintedCopy != 12604 ||
		result.PageMetrics.PrintedPrinter == nil || *result.PageMetrics.PrintedPrinter != 190990 ||
		result.PageMetrics.ScannedTotal == nil || *result.PageMetrics.ScannedTotal != 123468 {
		t.Fatalf("unexpected page metrics: %+v", result.PageMetrics)
	}
	if result.ConsumablePercent == nil || *result.ConsumablePercent != 73 {
		t.Fatalf("toner = %v, supplies = %+v", result.ConsumablePercent, result.Supplies)
	}
}

func TestWebDoesNotFollowAnotherHost(t *testing.T) {
	foreignHits := 0
	foreign := httptest.NewServer(http.HandlerFunc(func(http.ResponseWriter, *http.Request) { foreignHits++ }))
	defer foreign.Close()
	foreignURL := strings.Replace(foreign.URL, "127.0.0.1", "localhost", 1)
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		fmt.Fprintf(w, `<html><body>Kyocera printer<a href="%s/counter">Counter</a></body></html>`, foreignURL)
	}))
	defer server.Close()
	u, _ := url.Parse(server.URL)
	host, _, _ := net.SplitHostPort(u.Host)
	(Web{Timeout: time.Second}).Collect(config.Printer{Address: host, HTTPURL: server.URL})
	if foreignHits != 0 {
		t.Fatalf("followed a link to another host %d times", foreignHits)
	}
}

func TestWebCollectsKyoceraJavaScriptEndpoints(t *testing.T) {
	mux := http.NewServeMux()
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/" {
			http.NotFound(w, r)
			return
		}
		fmt.Fprint(w, `<html><frameset><frame src="/startwlm/Start_Wlm.htm"></frameset></html>`)
	})
	mux.HandleFunc("/startwlm/Start_Wlm.htm", func(w http.ResponseWriter, _ *http.Request) {
		fmt.Fprint(w, `<html><body><script>document.write("Command Center RX")</script></body></html>`)
	})
	mux.HandleFunc("/dvcinfo/dvccounter/DvcInfo_Counter_PrnCounter.htm", func(w http.ResponseWriter, r *http.Request) {
		if cookie, err := r.Cookie("rtl"); err != nil || cookie.Value != "0" {
			http.Error(w, "cookie required", http.StatusForbidden)
			return
		}
		fmt.Fprint(w, `<html><script src="/custom/model_counter.js"></script></html>`)
	})
	mux.HandleFunc("/custom/model_counter.js", func(w http.ResponseWriter, _ *http.Request) {
		fmt.Fprint(w, `counterBlackWhite[0] = "12,604"; counterBlackWhite[1] = 190990;`)
	})
	mux.HandleFunc("/dvcinfo/dvccounter/DvcInfo_Counter_ScanCounter.htm", func(w http.ResponseWriter, _ *http.Request) {
		fmt.Fprint(w, `counterBlackWhite[0] = 7110; counterBlackWhite[1] = 116358;`)
	})
	mux.HandleFunc("/startwlm/Hme_Toner.htm", func(w http.ResponseWriter, _ *http.Request) {
		fmt.Fprint(w, `tonerRemain[0] = 61;`)
	})
	server := httptest.NewServer(mux)
	defer server.Close()
	u, _ := url.Parse(server.URL)
	host, _, _ := net.SplitHostPort(u.Host)

	result := (Web{Timeout: time.Second}).Collect(config.Printer{Address: host, HTTPURL: server.URL + "/"})
	if result.Status != "ok" {
		t.Fatalf("status = %q, error = %q, warnings = %v", result.Status, result.Error, result.Warnings)
	}
	if result.TotalPages == nil || *result.TotalPages != 203594 {
		t.Fatalf("printed total = %v", result.TotalPages)
	}
	if result.PageMetrics == nil || result.PageMetrics.ScannedTotal == nil || *result.PageMetrics.ScannedTotal != 123468 {
		t.Fatalf("page metrics = %+v", result.PageMetrics)
	}
	if result.ConsumablePercent == nil || *result.ConsumablePercent != 61 {
		t.Fatalf("toner = %v", result.ConsumablePercent)
	}
}

func TestSummarizeHTTPFailures(t *testing.T) {
	got := summarizeHTTPFailures([]string{
		`http://192.0.2.1/: context deadline exceeded`,
		`http://192.0.2.1/counter: context deadline exceeded`,
		`http://192.0.2.1/toner: HTTP 404 Not Found`,
	})
	if got != "timeout=2, not found=1" {
		t.Fatalf("summary = %q", got)
	}
}

func TestGenericKyoceraCounterAndTonerVariables(t *testing.T) {
	result := Result{}
	parseKyoceraJavaScript(&result, `pageCountValues[7] = "106 297";`, "/custom/printer-counter.js")
	parseKyoceraJavaScript(&result, `blackTonerLevel = 6;`, "/custom/toner-status.js")
	if result.TotalPages == nil || *result.TotalPages != 106297 {
		t.Fatalf("printed total = %v", result.TotalPages)
	}
	if result.PageMetrics == nil || result.PageMetrics.PrintedPrinter == nil || *result.PageMetrics.PrintedPrinter != 106297 {
		t.Fatalf("page metrics = %+v", result.PageMetrics)
	}
	if result.ConsumablePercent == nil || *result.ConsumablePercent != 6 {
		t.Fatalf("toner = %v", result.ConsumablePercent)
	}
}

func TestKyoceraCounterFallbackForAnonymousFirmwareValues(t *testing.T) {
	result := Result{}
	source := `<html><body data-model="P2335dn"><script>
		var rows = [["Общий", "106297"]];
		var refreshed = "2026-09-03 18:13:12";
	</script></body></html>`
	parseKyoceraJavaScript(&result, source, "/dvcinfo/dvccounter/DvcInfo_Counter_PrnCounter.model.htm")
	if result.TotalPages == nil || *result.TotalPages != 106297 {
		t.Fatalf("printed total = %v", result.TotalPages)
	}
}

func TestMergeTreatsPrintedCounterAsSuccessfulWithoutToner(t *testing.T) {
	pages := int64(106297)
	result := mergeResults(
		Result{Status: "error", Error: "SNMP request timeout"},
		Result{Status: "ok", TotalPages: &pages, MetricSources: []string{"http"}},
	)
	if result.Status != "ok" || result.TotalPages == nil || *result.TotalPages != 106297 {
		t.Fatalf("merged result = %+v", result)
	}
}

func TestLikelyCounterTotalAvoidsDoubleCountingDisplayedTotal(t *testing.T) {
	if got := likelyCounterTotal([]int64{12604, 190990, 203594}); got != 203594 {
		t.Fatalf("total = %d", got)
	}
}

func TestWebParsesPrinterOnlyCounterAndTonerBySectionHeaders(t *testing.T) {
	mux := http.NewServeMux()
	mux.HandleFunc("/", func(w http.ResponseWriter, _ *http.Request) {
		fmt.Fprint(w, `<html><body>KYOCERA Command Center RX
		<section><h2>Тонер</h2><table><tr><td>Черный</td><td>6%</td></tr></table></section>
		<a href="/counter">Счетчик</a></body></html>`)
	})
	mux.HandleFunc("/counter", func(w http.ResponseWriter, _ *http.Request) {
		fmt.Fprint(w, `<html><body><h2>Напечатанные страницы</h2><table>
		<tr><th>Функция</th><th>Черно-белый</th><th>Общий</th></tr>
		<tr><td>Общий</td><td>106297</td><td>106297</td></tr></table></body></html>`)
	})
	server := httptest.NewServer(mux)
	defer server.Close()
	u, _ := url.Parse(server.URL)
	host, _, _ := net.SplitHostPort(u.Host)

	result := (Web{Timeout: time.Second}).Collect(config.Printer{Address: host, HTTPURL: server.URL + "/"})
	if result.TotalPages == nil || *result.TotalPages != 106297 {
		t.Fatalf("printed total = %v", result.TotalPages)
	}
	if result.PageMetrics == nil || result.PageMetrics.PrintedPrinter == nil || *result.PageMetrics.PrintedPrinter != 106297 {
		t.Fatalf("page metrics = %+v", result.PageMetrics)
	}
	if result.ConsumablePercent == nil || *result.ConsumablePercent != 6 {
		t.Fatalf("toner = %v", result.ConsumablePercent)
	}
}
