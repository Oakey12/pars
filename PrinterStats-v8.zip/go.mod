module printerstats

go 1.24.0

require (
	github.com/gosnmp/gosnmp v1.43.2
	github.com/xuri/excelize/v2 v2.10.0
	golang.org/x/net v0.50.0
)

require (
	github.com/richardlehane/mscfb v1.0.4 // indirect
	github.com/richardlehane/msoleps v1.0.4 // indirect
	github.com/tiendc/go-deepcopy v1.7.1 // indirect
	github.com/xuri/efp v0.0.1 // indirect
	github.com/xuri/nfp v0.0.2-0.20250530014748-2ddeb826f9a9 // indirect
	golang.org/x/crypto v0.48.0 // indirect
	golang.org/x/text v0.34.0 // indirect
)
